﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using cardal;
using carentities;
using carexceptions;

namespace carbal
{
    public class CarBal
    {
        public static bool IsValid(Car carobj)
        {
          
            StringBuilder errorMessage = new StringBuilder();
            bool valid = true;
            try
            {
                if (carobj.Type != "HatchBack" && carobj.Type != "SUV" && carobj.Type != "Sedan")
                {
                    valid = false;
                    errorMessage.AppendLine("Type name should be HatchBack or Sedan or SUV");
                }
                if (!(Regex.IsMatch(carobj.Engine, @"^\d\.\dL$")))
                {
                    valid = false;
                    errorMessage.AppendLine("Engine name should have 4 characters with 1st and 3rd character number ,2nd '.' and last 'L'");
                }
                if (!(Regex.IsMatch(carobj.BHP.ToString(), @"^[0-9]{1,3}$")))
                {
                    valid = false;
                    errorMessage.AppendLine("BHP should be a number");
                }
                if (carobj.Transmission != "Manual" && carobj.Transmission != "Automatic")
                {
                    valid = false;
                    errorMessage.AppendLine("Transmission type Should be either Manual or Automatic");
                }
                if (!(Regex.IsMatch(carobj.Mileage.ToString(), @"^[0-9]{2}$")))
                {
                    valid = false;
                    errorMessage.AppendLine("Mileage should be a number");
                }
                if (!(Regex.IsMatch(carobj.Seats.ToString(), @"^[0-9]{1}$")))
                {
                    valid = false;
                    errorMessage.AppendLine("seats should be a number");
                }
                if (!(Regex.IsMatch(carobj.AirBagDetails, @"^[A-Za-z]+$")))
                {
                    valid = false;
                    errorMessage.AppendLine("Airbags details should be a string");
                }
                if (!(Regex.IsMatch(carobj.BootSpace.ToString(), @"^[0-9]{1,3}$")))
                {
                    valid = false;
                    errorMessage.AppendLine("Bootspace should be a number with 3 digits");
                }
               
                if (!(Regex.IsMatch(carobj.Price.ToString(), @"^[0-9]+$")))
                {
                    valid = false;
                    errorMessage.AppendLine("Price should be a number");
                }
                if (!valid)
                {
                    throw new CarExceptions(errorMessage.ToString());
                }
            }
            catch (CarExceptions objCMSEx)
            {
                throw new CarExceptions(objCMSEx.Message);
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return valid;
        }
        public static bool AddCarBal(Car carobj)
        {
            bool CarAdded = false;
            try
            {
                if (IsValid(carobj))
                {
                    CarDal carDal = new CarDal();
                    CarAdded = carDal.AddCarDal(carobj);
                }
            }
            catch (CarExceptions objCMSEx)
            {
                throw new CarExceptions(objCMSEx.Message);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return CarAdded;
        }
        public static bool DeleteCarBal(string model)
        {
            bool carDeleted = false;
            try
            {
                if (model != null)
                {
                    CarDal carDal = new CarDal();
                    carDeleted = carDal.DeleteCarDal(model);
                }
                else
                {
                    throw new CarExceptions("Employee Id must be greater than 0.");
                }
            }
            catch (CarExceptions objCMSEx)
            {
                throw new CarExceptions(objCMSEx.Message);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return carDeleted;
        }
        public static bool UpdateCarBal(Car carobj)
        {
            bool carUpdated = false;
            try
            {
                if (IsValid(carobj))
                {
                    CarDal carDal = new CarDal();
                    carUpdated = carDal.UpdateCarDal(carobj);

                }
            }
            catch (CarExceptions objCMSEx)
            {
                throw new CarExceptions(objCMSEx.Message);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return carUpdated;
        }
        public static List<Car> SearchCarByNameBal(string Name,string Type)
        {
            List<Car> carobj = null;
            try
            {
                CarDal carDal = new CarDal();
                carobj = carDal.SearchCarByNameDal(Name,Type);
            }
            catch (CarExceptions objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return carobj;
        }
        public static Car SearchCarByModelBal(string model)
        {

            Car carobj = null;
            try
            {
                CarDal carDal = new CarDal();
                carobj = carDal.SearchCarByModelDal(model);
            }
            catch (CarExceptions objCIMSEx)
            {
                throw objCIMSEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return carobj;
        }
        public static List<Car> GetListBal()
        {
            List<Car> carsobj = null;
            try
            {
                CarDal carDal = new CarDal();
                carsobj = carDal.ListAllCarsDal();
            }
            catch (CarExceptions objCarEx)
            {
                throw objCarEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return carsobj;
        }
        public static bool userbl(string user, string pwd)
        {
            bool str = false;

            try
            {
                CarDal carobj = new CarDal();
                str = carobj.user(user, pwd);
            }

            catch (CarExceptions objCarEx)
            {
                throw objCarEx;
            }
            return str;
        }
    }
}
