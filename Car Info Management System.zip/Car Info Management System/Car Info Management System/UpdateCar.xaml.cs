﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using carbal;
using carentities;
using carexceptions;

namespace Car_Info_Management_System
{
    /// <summary>
    /// Interaction logic for Window5.xaml
    /// </summary>
    public partial class UpdateCar : Window
    {
        public UpdateCar()
        {
            InitializeComponent();
        }

        private void BtnUpdateCarDetails_Click(object sender, RoutedEventArgs e)
        {
            ModifyCar();
        }

        private void BtnHomePage_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            this.Close();
        }
        private void ModifyCar()
        {
            bool CarModified;
            try
            {
                Car objcar = new Car();
                objcar.ManufacturerName = cmbManufacturerName.Text;
                objcar.Model = txtModel.Text;
                objcar.Type = cmbCarType.Text;
                objcar.Engine = txtEngine.Text;
                objcar.BHP = Convert.ToInt32(txtBHP.Text);
                objcar.Transmission = cmbTransmissionType.Text;
                objcar.Mileage = Convert.ToInt32(txtMileage.Text);
                objcar.Seats = Convert.ToInt32(txtSeats.Text);
                objcar.AirBagDetails = txtAirbags.Text;
                objcar.BootSpace = Convert.ToInt32(txtBootSpace.Text);
                objcar.Price = Convert.ToDouble(txtPrice.Text);

                CarModified = CarBal.UpdateCarBal(objcar);


                if (CarModified)
                {
                    MessageBox.Show("Car Details updated successfully.");
                }
                else
                {
                    MessageBox.Show("Car Details couldn't be updated.");
                }
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        

            private void SearchCarBymodel()
            {
                try
                {
                    string model = txtModel.Text;
                    if (txtModel.Text != "")
                    {
                        Car objCar = CarBal.SearchCarByModelBal(model);
                        if (objCar != null)
                        {
                            cmbManufacturerName.Text = objCar.ManufacturerName.ToString();
                            cmbCarType.Text = objCar.Type.ToString();
                            txtEngine.Text = objCar.Engine;
                            txtBHP.Text = objCar.BHP.ToString();
                            cmbTransmissionType.Text = objCar.Transmission.ToString();
                            txtMileage.Text = objCar.Mileage.ToString();
                            txtSeats.Text = objCar.Seats.ToString();
                            txtAirbags.Text = objCar.AirBagDetails;
                            txtBootSpace.Text = objCar.BootSpace.ToString();
                            txtPrice.Text = objCar.Price.ToString();
                        }
                        else
                        {
                            MessageBox.Show("No Car records available.");
                        }
                    }
                    else
                        MessageBox.Show("Please Enter Model");

                }
                catch (CarExceptions ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        private void BtnSearchCarDetailsByModel_Click(object sender, RoutedEventArgs e)
        {
           SearchCarBymodel();
        }
    }
}
   
