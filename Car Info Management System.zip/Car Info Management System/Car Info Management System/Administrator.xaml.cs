﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Car_Info_Management_System
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Administrator : Window
    {
        public Administrator()
        {
            InitializeComponent();
        }

        private void BtnAddCarDetails_Click(object sender, RoutedEventArgs e)
        {

            AddCar addCar = new AddCar();
            addCar.Show();
            this.Close();
        }

        private void BtnUpdateCarDetails_Click(object sender, RoutedEventArgs e)
        {
            UpdateCar updateCar = new UpdateCar();
            updateCar.Show();
            this.Close();
        }

        private void BtnDeleteCarDetails_Click(object sender, RoutedEventArgs e)
        {
            DeleteCar deleteCar = new DeleteCar();
            deleteCar.Show();
            this.Close();
        }
        

        private void BtnGetDetails_Click(object sender, RoutedEventArgs e)
        {
            GetAllCars getAllCars = new GetAllCars();
            getAllCars.Show();
            this.Close();
        }

        private void BtnHomePage_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void BtnSearchCarByModel_Click(object sender, RoutedEventArgs e)
        {
            SearchCarByModel searchCarBM = new SearchCarByModel();
            searchCarBM.Show();
            this.Close();
        }

        private void BtnSearchCarByName_Click(object sender, RoutedEventArgs e)
        {
            GetAllCars getAllCars = new GetAllCars();
            getAllCars.Show();
            this.Close();
        }
    }
}
