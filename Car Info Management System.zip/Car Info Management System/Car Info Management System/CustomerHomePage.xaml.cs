﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using carbal;
using carentities;
using carexceptions;

namespace Car_Info_Management_System
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class CustomerHomePage : Window
    {
        public CustomerHomePage()
        {
            InitializeComponent();
        }
        private void SearchCarByModel()
        {
            try
            {
                string model = txtModel.Text;
                if (txtModel.Text != "")
                {
                    Car objCar = CarBal.SearchCarByModelBal(model);
                    if (objCar != null)
                    {
                        cmbname.Text = objCar.ManufacturerName.ToString();
                        cmbCarType.Text = objCar.Type.ToString();
                        txtEngine.Text = objCar.Engine;
                        txtBHP.Text = objCar.BHP.ToString();
                        cmbTransmissionType.Text = objCar.Transmission.ToString();
                        txtMileage.Text = objCar.Mileage.ToString();
                        txtSeats.Text = objCar.Seats.ToString();
                        txtAirBags.Text = objCar.AirBagDetails;
                        txtBootSpace.Text = objCar.BootSpace.ToString();
                        txtPrice.Text = objCar.Price.ToString();
                    }
                    else
                    {
                        MessageBox.Show("No Car records available.");
                    }
                }
                else
                    MessageBox.Show("Please Enter Model");

            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void SearchCarByName()
        {
            try
            {
                string name = cmbname.Text;
                string type = cmbCarType.Text;
                if (cmbname.Text != "" || cmbCarType.Text != "")
                {
                    List<Car> objCars = CarBal.SearchCarByNameBal(name, type);
                    if (objCars != null)
                    {
                        dgCars.ItemsSource = objCars;
                    }
                    else
                    {
                        MessageBox.Show("No records available.");
                    }
                }
                else
                    MessageBox.Show("Please Enter type And Manufacturer");
            }
            catch (CarExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearchCarByModel_Click(object sender, RoutedEventArgs e)
        {
            SearchCarByModel();
        }

        private void BtnSearchCarByName_Click(object sender, RoutedEventArgs e)
        {
            SearchCarByName();
        }



        private void BtnHomePage_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();

        }
    }
}
