﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using carentities;
using carexceptions;
using System.Configuration;

namespace cardal
{
    public class CarDal
    {
        SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["CARMSConnectionString"].ConnectionString);
        SqlDataReader objDr;
        public bool AddCarDal(Car car)
        {
            bool CarAdded = false;
            try
            {
                SqlCommand objCom = new SqlCommand("[46008229].AddCar", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                
                SqlParameter objSqlParam_Model = new SqlParameter("@Model", car.Model);
                SqlParameter objSqlParam_ManufacturerName = new SqlParameter("@ManName", car.ManufacturerName);
                SqlParameter objSqlParam_Type = new SqlParameter("@Type", car.Type);
                SqlParameter objSqlParam_Engine = new SqlParameter("@Engine", car.Engine);
                SqlParameter objSqlParam_BHP = new SqlParameter("@BHP", car.BHP);
                SqlParameter objSqlParam_Transmission = new SqlParameter("@Transmission", car.Transmission);
                SqlParameter objSqlParam_Mileage = new SqlParameter("@Mileage", car.Mileage);
                SqlParameter objSqlParam_Seats = new SqlParameter("@Seat", car.Seats);
                SqlParameter objSqlParam_AirBagDetails = new SqlParameter("@AirBags",car.AirBagDetails);
                SqlParameter objSqlParam_BootSpace = new SqlParameter("@BootSpace", car.BootSpace);
                SqlParameter objSqlParam_Price = new SqlParameter("@Price", car.Price);
    
                objCom.Parameters.Add(objSqlParam_Model);
                objCom.Parameters.Add(objSqlParam_ManufacturerName);
                objCom.Parameters.Add(objSqlParam_Type);
                objCom.Parameters.Add(objSqlParam_Engine);
                objCom.Parameters.Add(objSqlParam_BHP);
                objCom.Parameters.Add(objSqlParam_Transmission);
                objCom.Parameters.Add(objSqlParam_Mileage);
                objCom.Parameters.Add(objSqlParam_Seats);
                objCom.Parameters.Add(objSqlParam_AirBagDetails);
                objCom.Parameters.Add(objSqlParam_BootSpace);
                objCom.Parameters.Add(objSqlParam_Price);
 
                objCon.Open();
                objCom.ExecuteNonQuery();
                CarAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return CarAdded;
        }
        public bool DeleteCarDal(string model)
        {
            bool CarDeleted = false;
            SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["CARMSConnectionString"].ConnectionString);

            try
            {
                SqlCommand objCom = new SqlCommand("[46008229].DeleteCar", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                
                SqlParameter objSqlParam_Model = new SqlParameter("@Model", model);
                
                objCom.Parameters.Add(objSqlParam_Model);
                
                objCon.Open();
                objCom.ExecuteNonQuery();
                CarDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return CarDeleted;
        }
        public bool UpdateCarDal(Car car)
        {
            bool CarUpdated = false;
            try
            {
                SqlCommand objCom = new SqlCommand("[46008229].UpdateCar", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                
                SqlParameter objSqlParam_Model = new SqlParameter("@Model", car.Model);
                SqlParameter objSqlParam_ManufacturerName = new SqlParameter("@ManName", car.ManufacturerName);
                SqlParameter objSqlParam_Type = new SqlParameter("@Type", car.Type);
                SqlParameter objSqlParam_Engine = new SqlParameter("@Engine", car.Engine);
                SqlParameter objSqlParam_BHP = new SqlParameter("@BHP", car.BHP);
                SqlParameter objSqlParam_Transmission = new SqlParameter("@Transmission", car.Transmission);
                SqlParameter objSqlParam_Mileage = new SqlParameter("@Mileage", car.Mileage);
                SqlParameter objSqlParam_Seats = new SqlParameter("@Seat", car.Seats);
                SqlParameter objSqlParam_AirBagDetails = new SqlParameter("@AirBags", car.AirBagDetails);
                SqlParameter objSqlParam_BootSpace = new SqlParameter("@BootSpace", car.BootSpace);
                SqlParameter objSqlParam_Price = new SqlParameter("@Price", car.Price);

                //
                objCom.Parameters.Add(objSqlParam_Model);
                objCom.Parameters.Add(objSqlParam_ManufacturerName);
                objCom.Parameters.Add(objSqlParam_Type);
                objCom.Parameters.Add(objSqlParam_Engine);
                objCom.Parameters.Add(objSqlParam_BHP);
                objCom.Parameters.Add(objSqlParam_Transmission);
                objCom.Parameters.Add(objSqlParam_Mileage);
                objCom.Parameters.Add(objSqlParam_Seats);
                objCom.Parameters.Add(objSqlParam_AirBagDetails);
                objCom.Parameters.Add(objSqlParam_BootSpace);
                objCom.Parameters.Add(objSqlParam_Price);

                
                objCon.Open();
                objCom.ExecuteNonQuery();
                CarUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return CarUpdated;
        }
        
        public Car SearchCarByModelDal(string model)
        {
           
            Car objcar = new Car();
            try
            {
                objCon.Open();
                SqlCommand objCom = new SqlCommand("[46008229].SearchCarByModel", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCom.Parameters.AddWithValue("@model", model);
                //
               
                objDr = objCom.ExecuteReader();
                objDr.Read();
                if (objDr.HasRows)
                {
                    objcar = new Car();
                    objcar.Model = objDr[0].ToString();
                    objcar.ManufacturerName = objDr[1].ToString();           
                    objcar.Type = objDr[2].ToString();
                    objcar.Engine = objDr[3].ToString();
                    objcar.BHP = Convert.ToInt32(objDr[4].ToString());
                    objcar.Transmission = objDr[5].ToString();
                    objcar.Mileage = Convert.ToInt32(objDr[6].ToString());
                    objcar.Seats = Convert.ToInt32(objDr[7].ToString());
                    objcar.AirBagDetails = objDr[8].ToString();
                    objcar.BootSpace = Convert.ToInt32(objDr[9].ToString());
                   
                    objcar.Price = Convert.ToDouble(objDr[10].ToString());
                    
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objcar;
        }
        public List<Car> SearchCarByNameDal(string name,string type)
        {
            List<Car> Cars = new List<Car>();
            Car car = new Car();
            try
            {
                objCon.Open();
                SqlCommand objCom = new SqlCommand("[46008229].SearchCarByName", objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                objCom.Parameters.AddWithValue("@name", name);
                objCom.Parameters.AddWithValue("@CarType", type);
          
                objDr = objCom.ExecuteReader();
                objDr.Read();
                if (objDr.HasRows)
                {
                    //
                    car.ManufacturerName = objDr[0].ToString();
                    car.Model = objDr[1].ToString();
                    car.Type = objDr[2].ToString();
                    car.Price = Convert.ToDouble(objDr[3].ToString());
                    Cars.Add(car);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return Cars;
        }
        public List<Car> ListAllCarsDal()
        {
            List<Car> Cars = new List<Car>();
            try
            {
                objCon.Open();
                SqlCommand objCom = new SqlCommand("[46008229].ListCars", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //              
             
                objDr = objCom.ExecuteReader();
                if (objDr.HasRows)
                {
                    while (objDr.Read())
                    {
                        Car car = new Car();
                        car.ManufacturerName = objDr[0].ToString();
                        car.Model = objDr[1].ToString();
                        car.Type = objDr[2].ToString();
                        car.Price = Convert.ToDouble(objDr[3].ToString());
                        Cars.Add(car);
                    }
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return Cars;
        }
        public bool user(string uid, string pwd)
        {
            bool validate = false;
            try
            {

                SqlCommand objCom = new SqlCommand("[46008229].ValidateLogin", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                objCom.Parameters.AddWithValue("@UserId", uid);
                objCom.Parameters.AddWithValue("@Pwd", pwd);
                //
                objCon.Open();
                objDr = objCom.ExecuteReader();
                objDr.Read();
                if (objDr.HasRows)
                {
                    validate = true;

                }
                objCon.Close(); 
                return validate;
            }
            catch (SqlException objSqlEx)
            {
                throw new CarExceptions(objSqlEx.Message);
            }
        }
    }
}
