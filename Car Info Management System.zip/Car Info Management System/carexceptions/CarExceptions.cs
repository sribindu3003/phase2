﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace carexceptions
{
    public class CarExceptions:ApplicationException
    {
        public CarExceptions()
           : base()
        {
        }

        public CarExceptions(string message)
            : base(message)
        {
        }
        public CarExceptions(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}
